<?php
    require_once('db.php');
    header("Content-Type: application/json");
    if(isset($_POST['submit'])){
        $sql = "SELECT * FROM users";
        $result = $conn->query($sql);
        if ($result->num_rows >0) {
            $users = $result->fetch_all(MYSQLI_ASSOC);
            $response = array(
                'success' => true,
                'message' => 'Successfully fetched users',
                'users' => $users
            );
        } else{
            $response = array(
                'success' => false,
                'message' => 'Failed to fetch users'
            );
        }

        echo json_encode($response);
        exit;
    }
?>