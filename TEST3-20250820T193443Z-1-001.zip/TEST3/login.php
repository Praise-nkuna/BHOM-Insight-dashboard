<?php
    require_once('db.php');
    header("Content-Type: application/json");
    if(isset($_POST['email'])){
        $email= $conn->real_escape_string($_POST['email']);
        $password= $conn->real_escape_string($_POST['password']);
        
        $sql = "SELECT * FROM users WHERE email = '$email'";
        $result = $conn->query($sql);
        if ($result->num_rows>0) {
            $user = $result->fetch_assoc();
            $user_id = $user['id'];
            if ($user['password'] == $password) {
                $response = array(
                    'success' => true,
                    'message' => 'Successfully logged in',
                    'user_id' => $user_id
                );
            } else{
                $response = array(
                    'success' => false,
                    'message' => 'The password is incorrect, please try again'
                );
            }
        } else{
            $response = array(
                'success' => false,
                'message' => 'The user does not exist, please check your details if they are correct'
            );
        }

        echo json_encode($response);
        exit;
        # code...
    } 
?>