<?php
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\SMTP;
    use PHPMailer\PHPMailer\Exception;

    //Load Composer's autoloader
    require 'test3/vendor/autoload.php';
    require_once('db.php');
    header("Content-Type: application/json");
    if(isset($_POST['submit'])){
        $incidentId= $conn->real_escape_string($_POST['incidentId']);
        $progressNotes= $conn->real_escape_string($_POST['progressNotes']);
        $newStatus= $conn->real_escape_string($_POST['newStatus']);
        $notifyMember= $conn->real_escape_string($_POST['notifyMember']);
        
        if (isset($notifyMember)) {
            $sqlUdate = "UPDATE `incidents` SET `notes`='$progressNotes',`status`='$newStatus',`notify`='$notifyMember' WHERE `id` = '$incidentId'";
            $result = $conn->query($sqlUdate);
            if ($result === TRUE) {
                $sql = "SELECT * FROM users WHERE id = '$notifyMember'";
                $res = $conn->query($sql);
                if ($res->num_rows>0) {
                    $user = $res->fetch_assoc();
                    $email = $user['email'];
                }
                $sql = "SELECT * FROM incidents i INNER JOIN users u ON i.assign_to = u.id WHERE i.id = '$incidentId' ";
                $results = $conn->query($sql);
                if ($results->num_rows > 0){
                    $incident = $results->fetch_assoc();
                    $title = $incident['title'];
                    $notes = $incident['notes'];
                    $status = $incident['status'];
                    $priority = $incident['priority'];
                    $assignedName = $incident['name'];
                    $assignedEmail = $incident['email'];
                }
                $subject = "Incidinet Report Alert";
                $message = "Title: $title<br>
                            Update Notes: $notes<br>
                            Status: $status<br>
                            Priority: $priority";

                $mail = new PHPMailer(true);// Gmail SMTP settings
                $smtpHost = 'smtp.gmail.com';
                $smtpUsername = 'praisemorgets@gmail.com';
                $smtpPassword = 'uvgj qpfg ubxz spdh';  

                try {
                    $mail->isSMTP();                                            //Send using SMTP
                    $mail->Host = 'smtp.gmail.com';                     //Set the SMTP server to send through
                    $mail->SMTPAuth = true;                                   //Enable SMTP authentication
                    $mail->Username = 'praisemorgets@gmail.com';                     //SMTP username
                    $mail->Password = 'uvgj qpfg ubxz spdh';
                    $mail->SMTPSecure = 'tls';
                    $mail->Port = 587;
                    

                    //Recipients
                    $mail->setFrom($smtpUsername, 'Sars BHOM Insights');
                    $mail->addAddress($email, $user['name']);     //Add a recipient
                    $mail->addReplyTo($smtpUsername, 'Sars BHOM Insights');

                    //Content
                    $mail->isHTML(true);                                  //Set email format to HTML
                    $mail->Subject = $subject;
                    $mail->Body = $message;
                    $mail->AltBody = $message;

                    $mail->send();
                    $emailStatus = "Resest password link has been successfully sent to " . $email;
                    
                    $response = array(
                        'success' => true,
                        'message' => 'Email has been sent to your '.$email.', check your email to proceed',
                        'email' => 'Message has been sent',
                        'incidents' => $incidentId
                    );


                } catch (Exception $e) {
                        $response = array(
                            'success' => false,
                            'message' => 'Sign up was not successful, please try again',
                            'email' => 'Message could not be sent. Mailer Error: '.$mail->ErrorInfo
                        );
                }
            } else{
                $response = array(
                    'success' => false,
                    'message' => 'Failed to update an incident'
                );
            }
        } else{
            $sqlUdate = "UPDATE `incidents` SET `notes`='$progressNotes',`status`='$newStatus' WHERE `id` = '$incidentId'";
            $result = $conn->query($sqlUdate);
            if ($result === TRUE) {
                $response = array(
                    'success' => true,
                    'message' => 'Successfully updated an incident'
                );
            } else{
                $response = array(
                    'success' => false,
                    'message' => 'Failed to update an incident'
                );
            }
        }

        echo json_encode($response);
        exit;
        # code...
    }
?>