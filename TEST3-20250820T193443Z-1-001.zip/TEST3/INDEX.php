<?php
    require_once('db.php');
    $sql = "SELECT * FROM users";
    $result = $conn->query($sql);
    if ($result->num_rows > 0){
        $users = $result->fetch_all(MYSQLI_ASSOC);
    } else {
        $users = [];
    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SARS BHOM Intergration App</title>
    <!-- Bootstrap CSS CDN for styling and layout -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons CDN -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background-color: #f1f5f9;
        }
        .sidebar {
            background-color: #2b3a4a;
            color: #f8f9fa;
            width: 250px;
            min-height: 100vh;
            transition: width 0.3s ease;
        }
        .sidebar.collapsed {
            width: 80px;
        }
        .main-content {
            flex-grow: 1;
        }
        .card {
            border-radius: 1.5rem;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            transition: transform 0.2s;
        }
        .card:hover {
            transform: translateY(-5px);
        }
        .nav-link.active, .nav-link:hover {
            background-color: #3b4e60;
            border-radius: 0.5rem;
        }
        .nav-link {
            transition: background-color 0.2s;
            border-radius: 0.5rem;
        }
        /* Custom styles for the message box, incident modal, and login page */
        .modal-backdrop {
            background-color: rgba(0, 0, 0, 0.5);
        }
        #login-page {
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            background-color: #e2e8f0;
        }
        #main-app {
            display: none;
        }
    </style>
</head>
<body>

    <!-- Login Page -->
    <div id="login-page">
        <div class="card p-5 shadow-lg rounded-5" style="width: 100%; max-width: 400px;">
            <h3 class="card-title text-center mb-4 fw-bold">SARS BHOM Insights Login</h3>
            <form id="login-form">
                <div class="mb-3">
                    <label for="username" class="form-label">Username</label>
                    <input type="text" class="form-control rounded-pill" id="username" placeholder="admin" required>
                </div>
                <div class="mb-4">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" class="form-control rounded-pill" id="password" placeholder="password" required>
                </div>
                <div id="login-error" class="alert alert-danger d-none" role="alert">
                    Invalid username or password.
                </div>
                <button type="submit" class="btn btn-primary w-100 rounded-pill fw-semibold">Sign In</button>
            </form>
        </div>
    </div>

    <!-- Main Application Container -->
    <div id="main-app">
        <!-- Main container with a flex layout -->
        <div class="d-flex">

            <!-- Sidebar -->
            <aside id="sidebar" class="sidebar d-flex flex-column p-3">
                <div class="d-flex align-items-center mb-4">
                    <h2 class="fs-4 fw-bold mb-0 me-auto">SARS BHOM App</h2>
                    <button class="btn btn-sm btn-outline-light d-lg-none" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="bi bi-list"></span>
                    </button>
                </div>
                <nav class="flex-grow-1">
                    <ul class="nav flex-column gap-2" id="navbarNav">
                        <li class="nav-item">
                            <a class="nav-link text-white active" href="#" data-tab="dashboard">
                                <i class="bi bi-speedometer2 me-2"></i>
                                <span class="d-none d-md-inline">Dashboard</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="#" data-tab="incidents">
                                <i class="bi bi-bell-fill me-2"></i>
                                <span class="d-none d-md-inline">Incidents</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="#" data-tab="workflows">
                                <i class="bi bi-share me-2"></i>
                                <span class="d-none d-md-inline">Workflows</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="#" data-tab="kpis">
                                <i class="bi bi-bar-chart-fill me-2"></i>
                                <span class="d-none d-md-inline">KPIs</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="#" data-tab="reports">
                                <i class="bi bi-file-text me-2"></i>
                                <span class="d-none d-md-inline">Reports</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="#" data-tab="centralized">
                                <i class="bi bi-diagram-3-fill me-2"></i>
                                <span class="d-none d-md-inline">Centralized Ops</span>
                            </a>
                        </li>
                    </ul>
                </nav>
                <div class="mt-auto pt-3 border-top border-secondary">
                    <div class="text-white-50 small">User: Admin</div>
                    <div class="text-white-50 small">SARS BHOM Intergration App</div>
                </div>
            </aside>

            <!-- Main content area -->
            <main class="main-content d-flex flex-column">

                <!-- Header -->
                <header class="bg-white p-4 shadow-sm sticky-top">
                    <div class="d-flex justify-content-between align-items-center">
                        <h1 class="fs-3 fw-bold text-dark mb-0">SARS BHOM Insights</h1>
                        <div class="d-flex gap-3">
                            <button class="btn btn-outline-secondary rounded-pill d-flex align-items-center gap-2">
                                <i class="bi bi-search"></i>
                            </button>
                            <button class="btn btn-primary rounded-pill d-flex align-items-center gap-2" id="NewIncident">
                                <i class="bi bi-plus-circle"></i> New Incident
                            </button>
                        </div>
                    </div>
                </header>

                <!-- Dynamic content area -->
                <div id="content-area" class="p-4 flex-grow-1">
                    <!-- Content will be injected here by JavaScript -->
                </div>

            </main>
        </div>
    </div>

    <!-- Incident Detail Modal -->
    <div class="modal fade" id="incidentModal" tabindex="-1" aria-labelledby="incidentModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="incidentModalLabel">Incident Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <h4 id="modal-incident-title" class="fw-bold mb-3"></h4>
                    <p><strong>Status:</strong> <span id="modal-incident-status"></span></p>
                    <p><strong>Priority:</strong> <span id="modal-incident-priority"></span></p>
                    <p><strong>Assigned To:</strong> <span id="modal-incident-assigned"></span></p>
                    <p><strong>Created:</strong> <span id="modal-incident-created"></span></p>
                    <hr>

                    <!-- New form for updating progress and status -->
                    <form id="update-incident-form">
                        <div class="mb-3">
                            <label for="progress-notes" class="form-label">Progress Notes</label>
                            <textarea class="form-control rounded-4" id="progress-notes" rows="3" placeholder="Enter notes on the incident progress..."></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="new-status" class="form-label">Update Status</label>
                            <select class="form-select rounded-pill" id="new-status" required>
                                <!-- Options will be dynamically populated -->
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="notify-team-member" class="form-label">Notify Team Member (via Teams)</label>
                            <select class="form-select rounded-pill" id="notify-team-member">
                                <option value="" disabled selected>Select a team member...</option>
                                <?php
                                    foreach ($users as $user) {
                                        echo '<option value="'.$user['id'].'">'.$user['name'].'</option>';
                                    }
                                ?>
                            </select>
                            <div class="form-text">Selecting a member will send a simulated notification to a Teams channel.</div>
                        </div>
                        <div class="d-flex justify-content-between">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary" id="submit-update-btn">
                                <i class="bi bi-save me-2"></i>Update Incident
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="InsertIncidentModal" tabindex="-1" aria-labelledby="insertIncidentModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="insertIncidentModalLabel">Create New Incident</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="insert-incident-form">
                        <div class="mb-3">
                            <label for="incident-title" class="form-label">Incident Title</label>
                            <input type="text" class="form-control rounded-4" id="incident-title" placeholder="Enter incident title..." required>
                        </div>
                        <div class="mb-3">
                            <label for="incident-notes" class="form-label">Notes</label>
                            <textarea class="form-control rounded-4" id="incident-notes" rows="3" placeholder="Enter incident notes..."></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="incident-priority" class="form-label">Priority</label>
                            <select class="form-select rounded-pill" id="incident-priority" required>
                                <option value="" disabled selected>Select priority...</option>
                                <option value="Low">Low</option>
                                <option value="Medium">Medium</option>
                                <option value="High">High</option>
                                <option value="Critical">Critical</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="incident-assigned" class="form-label">Assign To</label>
                            <select class="form-select rounded-pill" id="incident-assigned" required>
                                <option value="" disabled selected>Select a team member...</option>
                                <?php
                                    foreach ($users as $user) {
                                        echo '<option value="'.$user['id'].'">'.$user['name'].'</option>';
                                    }
                                ?>
                            </select>
                        </div>
                        <div class="d-flex justify-content-between">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary" id="submit-insert-btn">
                                <i class="bi bi-save me-2"></i>Create Incident
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- Custom message box for alerts -->
    <div class="modal fade" id="messageBox" tabindex="-1" aria-labelledby="messageBoxLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="messageBoxLabel"></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body" id="messageBoxBody"></div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap and JS CDNs -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script>
        // Use an IIFE (Immediately Invoked Function Expression) to avoid global scope pollution
        (() => {
            // Helper function to format the current date as YYYY-MM-DD
            const getCurrentDate = () => {
                const today = new Date();
                const year = today.getFullYear();
                const month = String(today.getMonth() + 1).padStart(2, '0');
                const day = String(today.getDate()).padStart(2, '0');
                return `${year}-${month}-${day}`;
            };

            // Mock data that would come from a PHP backend and MySQL database
            const mockData = {
                incidents: [
                    { id: 1, title: 'Service A Outage', status: 'Open', priority: 'High', assigned: 'Jane Doe', created: getCurrentDate(), description: 'The API Gateway is unresponsive, affecting all dependent services. Investigation required.' },
                    { id: 2, title: 'Database Connection Error', status: 'Open', priority: 'Medium', assigned: 'John Smith', created: getCurrentDate(), description: 'Connections to the main application database are failing. Check connection pool settings.' },
                    { id: 3, title: 'Server Load Spike', status: 'Resolved', priority: 'Low', assigned: 'Jane Doe', created: getCurrentDate(), description: 'Unexpected CPU spike on production server. Cause was a scheduled job that ran out of control.' },
                ],
                services: [
                    { name: 'API Gateway', status: 'healthy' },
                    { name: 'Auth Service', status: 'unhealthy' },
                    { name: 'Database', status: 'degraded' },
                    { name: 'Payment Service', status: 'healthy' },
                ],
                kpis: [
                    { name: 'MTTR', value: 45, unit: 'minutes' },
                    { name: 'SLA Breaches', value: 12, unit: 'breaches' },
                    { name: 'Availability', value: 99.8, unit: '%' },
                ],
                historicalKpis: {
                    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                    mttrData: [50, 48, 42, 35, 30, 25], // Simulated improvement over time
                    slaBreachData: [15, 14, 11, 9, 8, 5] // Simulated improvement over time
                },
                reports: [
                    { id: 1, name: 'Monthly Incident Postmortem - ' + getCurrentDate(), type: 'Postmortem', date: getCurrentDate() },
                    { id: 2, name: 'Q3 KPI Summary Report', type: 'KPI Summary', date: '2023-10-15' },
                    { id: 3, name: 'Service A Outage Analysis', type: 'Postmortem', date: '2023-09-28' },
                ],
                centralized: {
                    discovery: {
                        devicesFound: 150,
                        lastRun: getCurrentDate(),
                        status: 'Scheduled',
                        scanResults: [
                            { ip: '192.168.1.1', hostname: 'server-prod-01', os: 'Linux', type: 'Server' },
                            { ip: '192.168.1.2', hostname: 'router-main', os: 'Cisco IOS', type: 'Network Device' },
                            { ip: '192.168.1.3', hostname: 'db-replica-01', os: 'Windows Server', type: 'Database' },
                        ],
                        // NEW MOCK DATA: Discovered assets with more detail
                        discoveredAssets: [
                            { id: 1, name: 'Web Server A', type: 'Infrastructure', ip: '10.0.1.10', os: 'Ubuntu 22.04', status: 'Operational' },
                            { id: 2, name: 'Auth Service API', type: 'Application', ip: '10.0.1.11', os: 'Docker/Linux', status: 'Degraded' },
                            { id: 3, name: 'Primary Database', type: 'Infrastructure', ip: '10.0.1.12', os: 'PostgreSQL', status: 'Operational' },
                            { id: 4, name: 'Firewall 01', type: 'Network', ip: '10.0.0.1', os: 'Cisco ASA', status: 'Operational' },
                            { id: 5, name: 'User Management Service', type: 'Application', ip: '10.0.1.11', os: 'Docker/Linux', status: 'Down' },
                        ]
                    },
                    netreo: {
                        monitoredDevices: 120,
                        alertsLast24h: 5,
                        connectorStatus: 'Active',
                        monitored: [
                            { name: 'server-prod-01', status: 'Up', latency: '2ms', cpu: '15%', memory: '40%' },
                            { name: 'router-main', status: 'Up', latency: '1ms', cpu: '5%', memory: '25%' },
                            { name: 'db-replica-01', status: 'Up', latency: '3ms', cpu: '30%', memory: '75%' },
                            { name: 'auth-service-vm', status: 'Down', latency: 'N/A', cpu: 'N/A', memory: 'N/A' },
                        ],
                        alerts: [
                            { id: 1, device: 'db-replica-01', type: 'High CPU', severity: 'Warning', timestamp: '1:45 PM' },
                            { id: 2, device: 'auth-service-vm', type: 'Service Down', severity: 'Critical', timestamp: '1:40 PM' },
                        ]
                    },
                    aiops: {
                        activeInsights: 3,
                        predictedOutages: 1,
                        insights: [
                            { id: 1, title: 'Predictive Outage: Auth Service', description: 'Trend analysis of CPU and memory indicates a high probability of outage within the next 24 hours.', severity: 'High' },
                            { id: 2, title: 'Resource Optimization Opportunity', description: 'Identified underutilized virtual machines. Recommending a resource reduction of 20%.', severity: 'Medium' },
                            { id: 3, title: 'High Latency Anomaly Detected', description: 'Network latency on server-prod-01 is increasing. This may be an early indicator of a network issue.', severity: 'Medium' },
                        ]
                    },
                },
            };

            
            // Workflow options for the new form, now business-oriented
            const workflowOptions = [
                { id: 'restart-service', name: 'Restart a critical service' },
                { id: 'clear-cache', name: 'Clear the application cache' },
                { id: 'run-compliance-check', name: 'Run compliance check on all servers' },
                { id: 'generate-weekly-report', name: 'Generate and send weekly report' },
                { id: 'trigger-outage-alert', name: 'Trigger a major outage alert' }
            ];

            // Main function to handle navigation and render content
            document.addEventListener('DOMContentLoaded', () => {
                const navLinks = document.querySelectorAll('[data-tab]');
                const contentArea = document.getElementById('content-area');
                const loginForm = document.getElementById('login-form');
                const NewIncident = document.getElementById('NewIncident');
                const insertIncForm = document.getElementById('insert-incident-form');
                const loginPage = document.getElementById('login-page');
                const mainApp = document.getElementById('main-app');
                const loginError = document.getElementById('login-error');

                let incidentData = [];

                // Function to fetch incidents and store them globally
                const fetchIncidents = () => {
                    return new Promise((resolve, reject) => {
                        $.ajax({
                            url: "/get-incident-api",
                            method: "POST",
                            data: { submit: true },
                            dataType: "json",
                            success: function(response) {
                                if (response.success === true) {
                                    incidentData = response.incidents; // Store data globally
                                    resolve(incidentData);
                                } else {
                                    console.log(response);
                                    reject(new Error('Failed to fetch incidents'));
                                }
                            },
                            error: function(xhr, status, error) {
                                console.error(error);
                                reject(new Error('Error fetching incidents'));
                            }
                        });
                        });
                };
                fetchIncidents();
                let usersData = [];

                // Function to fetch incidents and store them globally
                const fetchUsers = () => {
                    return new Promise((resolve, reject) => {
                        $.ajax({
                            url: "/get-users-api",
                            method: "POST",
                            data: { submit: true },
                            dataType: "json",
                            success: function(response) {
                                if (response.success === true) {
                                    usersData = response.users; // Store data globally
                                    resolve(usersData);
                                } else {
                                    console.log(response);
                                    reject(new Error('Failed to fetch users'));
                                }
                            },
                            error: function(xhr, status, error) {
                                console.error(error);
                                reject(new Error('Error fetching users'));
                            }
                        });
                        });
                };
                fetchUsers();
                // Handle login form submission
                loginForm.addEventListener('submit', (e) => {
                    e.preventDefault();
                    const username = document.getElementById('username').value;
                    const password = document.getElementById('password').value;

                    $.ajax({
                        url: "/login",
                        method: "POST", // or "POST", "PUT", "DELETE"
                        data: { email: username, password: password }, // Data to send with the request
                        dataType: "json", // Expected data type from the server (e.g., "json", "xml", "html")
                        success: function(response) {                            
                            if (response.success == true) {
                                loginPage.style.display = 'none';
                                mainApp.style.display = 'block';
                                renderContent('dashboard');
                            } else{
                                loginError.classList.remove('d-none');;
                            }
                            console.log(response.message);
                        },
                        error: function(xhr, status, error) {
                            // Handle errors
                            console.error(error);
                        }
                    });
                });

                insertIncForm.addEventListener('submit', (e) => {
                    e.preventDefault();
                    const title = document.getElementById('incident-title').value;
                    const notes = document.getElementById('incident-notes').value;
                    const prioty = document.getElementById('incident-priority').value;
                    const assigned = document.getElementById('incident-assigned').value;

                    $.ajax({
                        url: "/create-incident-api",
                        method: "POST", // or "POST", "PUT", "DELETE"
                        data: { title, notes, prioty, assigned }, // Data to send with the request
                        dataType: "json", // Expected data type from the server (e.g., "json", "xml", "html")
                        success: function(response) {                            
                            if (response.success == true) {
                                console.log(response.message);
                            } else{
                                console.log(response.message);
                            }
                        },
                        error: function(xhr, status, error) {
                            // Handle errors
                            console.error(error);
                        }
                    });
                });
                
                // Add click event listeners to all navigation links
                navLinks.forEach(link => {
                    link.addEventListener('click', (e) => {
                        e.preventDefault();
                        const tab = e.target.closest('[data-tab]').dataset.tab;
                        setActiveTab(tab);
                        renderContent(tab);
                    });
                });

                // Function to set the active navigation link
                const setActiveTab = (tab) => {
                    navLinks.forEach(link => {
                        if (link.dataset.tab === tab) {
                            link.classList.add('active');
                        } else {
                            link.classList.remove('active');
                        }
                    });
                };

                // Function to render the correct content based on the selected tab
                const renderContent = (tab) => {
                    let htmlContent = '';
                    switch (tab) {
                        case 'dashboard':
                            htmlContent = renderDashboard();
                            break;
                        case 'incidents':
                            htmlContent = renderIncidents();
                            break;
                        case 'workflows':
                            htmlContent = renderWorkflows();
                            break;
                        case 'kpis':
                            htmlContent = renderKPIs();
                            break;
                        case 'reports':
                            htmlContent = renderReports();
                            break;
                        case 'centralized':
                            htmlContent = renderCentralizedDashboard('overview'); // Default to overview
                            break;
                    }
                    contentArea.innerHTML = htmlContent;
                    
                    // Re-initialize charts if they exist in the rendered content
                    if (tab === 'dashboard' || tab === 'kpis') {
                        renderCharts();
                    }

                    // Add event listeners for new incident detail buttons
                    if (tab === 'incidents') {
                        document.querySelectorAll('.view-incident-btn').forEach(button => {
                            button.addEventListener('click', (e) => {
                                const incidentId = e.target.closest('tr').dataset.incidentId;
                                const incident = incidentData.find(inc => inc.id === parseInt(incidentId));
                                let inc = [];
                                incidentData.forEach(iiid => {
                                    if (iiid['id'] == parseInt(incidentId)) {
                                        inc = iiid;
                                    }
                                });
                                console.log(inc);
                                
                                showIncidentModal(inc);
                            });
                        });
                    }
                    
                    // Add event listener for the new workflow form
                    if (tab === 'workflows') {
                        attachWorkflowFormListener();
                    }
                    
                    // Add event listeners for centralized sub-tabs
                    if (tab === 'centralized') {
                        document.querySelectorAll('[data-centralized-tab]').forEach(subTabLink => {
                            subTabLink.addEventListener('click', (e) => {
                                e.preventDefault();
                                const subTab = e.target.closest('[data-centralized-tab]').dataset.centralizedTab;
                                document.getElementById('centralized-content-area').innerHTML = renderCentralizedSubTab(subTab);
                                // Set active class on sub-nav links
                                document.querySelectorAll('[data-centralized-tab]').forEach(link => link.classList.remove('active'));
                                e.target.closest('[data-centralized-tab]').classList.add('active');
                            });
                        });
                        // Manually set overview as active on initial load
                        document.querySelector('[data-centralized-tab="overview"]').classList.add('active');
                    }
                };

                // Render the dashboard content
                const renderDashboard = () => {
                    const openIncidents = incidentData.filter(i => i.status === 'Open').length;
                    const inProgress = incidentData.filter(i => i.status === 'In Progress').length;
                    const resolvedToday = incidentData.filter(i => i.status === 'Resolved').length;
                    const healthyServices = mockData.services.filter(s => s.status === 'healthy').length;
                    
                    return `
                        <h1 class="fs-2 fw-bold text-dark mb-4">SARS BHOM Intergration App Dashboard</h1>
                        
                        <!-- Overview Cards -->
                        <div class="row g-4 mb-4">
                            ${renderCard('Open Incidents', openIncidents, 'bg-danger text-white')}
                            ${renderCard('In Progress', inProgress, 'bg-warning text-white')}
                            ${renderCard('Resolved Today', resolvedToday, 'bg-success text-white')}
                            ${renderCard('Service Status', `${healthyServices}/${mockData.services.length}`, 'bg-primary text-white')}
                        </div>

                        <!-- Service Health and KPI Section -->
                        <div class="row g-4">
                            <!-- Service Health -->
                            <div class="col-lg-6">
                                <div class="card p-4">
                                    <h2 class="fs-4 fw-semibold mb-3">Service Health</h2>
                                    <div class="row g-3">
                                        ${mockData.services.map(service => renderServiceTile(service)).join('')}
                                    </div>
                                </div>
                            </div>

                            <!-- Key Performance Indicators -->
                            <div class="col-lg-6">
                                <div class="card p-4">
                                    <h2 class="fs-4 fw-semibold mb-3">Key Performance Indicators</h2>
                                    <canvas id="dashboardKpiChart"></canvas>
                                </div>
                            </div>
                        </div>
                    `;
                };

                // Helper function to render a single card
                const renderCard = (title, value, bgColor) => `
                    <div class="col-12 col-md-6 col-lg-3">
                        <div class="card p-4 text-center ${bgColor}">
                            <div class="text-uppercase small fw-medium opacity-75">${title}</div>
                            <div class="fs-1 fw-bold mt-2">${value}</div>
                        </div>
                    </div>
                `;

                // Helper function to render a service health tile
                const renderServiceTile = (service) => {
                    let statusClass, statusText;
                    switch (service.status) {
                        case 'healthy':
                            statusClass = 'bg-success-subtle text-success border-success';
                            statusText = 'Healthy';
                            break;
                        case 'unhealthy':
                            statusClass = 'bg-danger-subtle text-danger border-danger';
                            statusText = 'Unhealthy';
                            break;
                        case 'degraded':
                            statusClass = 'bg-warning-subtle text-warning border-warning';
                            statusText = 'Degraded';
                            break;
                        default:
                            statusClass = 'bg-secondary-subtle text-secondary border-secondary';
                            statusText = 'Unknown';
                    }

                    return `
                        <div class="col-12 col-sm-6">
                            <div class="d-flex align-items-center p-3 rounded-2 border ${statusClass}">
                                <span class="d-inline-block rounded-circle me-3" style="width: 10px; height: 10px; background-color: ${service.status === 'healthy' ? '#198754' : service.status === 'unhealthy' ? '#dc3545' : '#ffc107'};"></span>
                                <div class="flex-grow-1">
                                    <div class="fw-semibold">${service.name}</div>
                                    <div class="small opacity-90">${statusText}</div>
                                </div>
                            </div>
                        </div>
                    `;
                };
                const getIncidents = () => {
                    const data = []; 
                    $.ajax({
                        url: "/get-incident-api",
                        method: "POST", // or "POST", "PUT", "DELETE"
                        data: { submit: true }, // Data to send with the request
                        dataType: "json", // Expected data type from the server (e.g., "json", "xml", "html")
                        success: function(response) {                            
                            if (response.success == true) {
                                data = response.incidents;
                                console.log(response);
                            } else{
                                console.log(response);
                            }
                        },
                        error: function(xhr, status, error) {
                            // Handle errors
                            console.error(error);
                        }
                    });
                    return data;
                };
                // Function to render the incidents table
                const renderIncidents = () => {
                    const tableRows = incidentData.map(incident => `
                        <tr data-incident-id="${incident.id}">
                            <td>${incident.title}</td>
                            <td><span class="badge ${getIncidentStatusBadge(incident.status)}">${incident.status}</span></td>
                            <td>${incident.priority}</td>
                            <td>${incident.name}</td>
                            <td>${incident.created_at}</td>
                            <td><button class="btn btn-sm btn-info view-incident-btn">View Details</button></td>
                        </tr>
                    `).join('');

                    return `
                        <h1 class="fs-2 fw-bold text-dark mb-4">Incidents</h1>
                        <div class="card p-4">
                            <div class="table-responsive">
                                <table class="table table-striped table-hover">
                                    <thead>
                                        <tr>
                                            <th>Title</th>
                                            <th>Status</th>
                                            <th>Priority</th>
                                            <th>Assigned To</th>
                                            <th>Created</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        ${tableRows}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    `;
                };
                
                // Helper to get bootstrap badge class for incident status
                const getIncidentStatusBadge = (status) => {
                    switch (status) {
                        case 'Open': return 'bg-danger';
                        case 'In Progress': return 'bg-warning text-dark';
                        case 'Resolved': return 'bg-success';
                        default: return 'bg-secondary';
                    }
                };
                
                // Show incident details in a modal
                const showIncidentModal = (incident) => {
                    const modalEl = document.getElementById('incidentModal');
                    const form = document.getElementById('update-incident-form');
                    const newStatusSelect = document.getElementById('new-status');
                    
                    // Populate basic incident details
                    document.getElementById('modal-incident-title').textContent = incident.title;
                    document.getElementById('modal-incident-status').textContent = incident.status;
                    document.getElementById('modal-incident-priority').textContent = incident.priority;
                    document.getElementById('modal-incident-assigned').textContent = incident.name;
                    document.getElementById('modal-incident-created').textContent = incident.created_at;
                    
                    // Clear previous options and populate new ones based on current status
                    newStatusSelect.innerHTML = ''; // Clear previous options
                    if (incident.status === 'Open') {
                        newStatusSelect.innerHTML = `
                            <option value="In Progress" selected>In Progress</option>
                            <option value="Resolved">Resolved</option>
                        `;
                    } else if (incident.status === 'In Progress') {
                        newStatusSelect.innerHTML = `
                            <option value="In Progress" disabled selected>In Progress</option>
                            <option value="Resolved">Resolved</option>
                        `;
                    } else if (incident.status === 'Resolved') {
                        newStatusSelect.innerHTML = `
                            <option value="Resolved" disabled selected>Resolved</option>
                        `;
                    } else if (incident.status === 'Acknowledge') {
                        newStatusSelect.innerHTML = `
                            <option value="Acknowledge" disabled selected>Acknowledge</option>
                            <option value="Resolved" disabled selected>Resolved</option>
                        `;
                    }
                    
                    // Set the form data-incident-id attribute for easy access in the submit handler
                    form.setAttribute('data-incident-id', incident.id);
                    
                    // Remove any previous event listeners to prevent duplicates
                    form.removeEventListener('submit', handleUpdateIncident);
                    // Add the new event listener
                    form.addEventListener('submit', handleUpdateIncident);

                    const myModal = new bootstrap.Modal(modalEl);
                    myModal.show();
                };

                NewIncident.addEventListener('click', (e) => {
                    e.preventDefault();
                    console.log('here');
                    
                    const modalEl = document.getElementById('InsertIncidentModal');
                    const myModal = new bootstrap.Modal(modalEl);
                    myModal.show();
                });
                const showCreateIncidentModal = () => {
                    const modalEl = document.getElementById('InsertIncidentModal');
                    myModal.show();
                };

                // Function to handle the form submission for updating an incident
                const handleUpdateIncident = (e) => {
                    e.preventDefault();
                    
                    const form = e.target;
                    const incidentId = parseInt(form.getAttribute('data-incident-id'));
                    const progressNotes = document.getElementById('progress-notes').value;
                    const newStatus = document.getElementById('new-status').value;
                    const notifyMember = document.getElementById('notify-team-member').value;
                    
                    $.ajax({
                        url: "/update-incident-api",
                        method: "POST",
                        data: { submit: true, incidentId, notifyMember, progressNotes, newStatus },
                        dataType: "json",
                        success: function(response) {
                            if (response.success === true) {
                                console.log(`Incident ${incidentId} updated with notes: ${progressNotes}`);
                                
                                const index = incidentData.findIndex(inc => inc.id == updatedIncident.id); 
                                if (index !== -1) {                                                                     
                                    incidentData[index].status = newStatus;
                                    incidentData[index].notes = progressNotes;
                                };
                                renderIncidents();
                                
                                // Re-render the incidents table immediately
                                document.getElementById('content-area').innerHTML = renderIncidents();
                                
                                let message = `Incident #${incidentId} has been updated to "${newStatus}".`;
                                if (notifyMember) {
                                    message += `\n\nSimulated Teams notification sent to ${notifyMember}.`;
                                }
                                showMessageBox('Success', message);
                            } else {
                                console.log(response);
                                showMessageBox('Error', 'Failed to update incident.');
                            }
                        },
                        error: function(xhr, status, error) {
                            console.error(error);
                            showMessageBox('Error', 'Error updating incident.');
                        }
                    });

                    // Reset form and close modal
                    form.reset();
                    const modalEl = document.getElementById('incidentModal');
                    const modal = bootstrap.Modal.getInstance(modalEl);
                    modal.hide();
                };

                // Function to update incident status and re-render
                // This function is now deprecated in favor of the new form handler
                const updateIncidentStatus = (id, newStatus) => {
                    const incidentToUpdate = incidentData.find(inc => inc.id === id);
                    if (incidentToUpdate) {
                        incidentToUpdate.status = newStatus;
                        // Re-render the incidents table to reflect the change
                        renderContent('incidents');
                        showMessageBox('Success', `Incident #${id} has been updated to "${newStatus}".`);
                    } else {
                        showMessageBox('Error', `Incident #${id} not found.`);
                    }
                };

                // Function to render the new workflows UI with a form
                const renderWorkflows = () => `
                    <h1 class="fs-2 fw-bold text-dark mb-4">Workflow Automation</h1>
                    <p class="text-muted mb-4">
                        Easily trigger common business-oriented workflows without needing technical expertise.
                    </p>
                    <div class="card p-4">
                        <form id="workflow-form">
                            <div class="mb-3">
                                <label for="workflow-type" class="form-label">Select a Business Action</label>
                                <select class="form-select rounded-pill" id="workflow-type" required>
                                    <option value="" disabled selected>Choose a common action...</option>
                                    ${workflowOptions.map(wf => `<option value="${wf.id}">${wf.name}</option>`).join('')}
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="business-reason" class="form-label">Reason for Action (Business Justification)</label>
                                <textarea class="form-control rounded-4" id="business-reason" rows="4" placeholder="e.g., 'Due to a recent support ticket from the marketing team, we need to clear the cache.'"></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary w-100 rounded-pill fw-semibold">
                                <i class="bi bi-play-circle me-2"></i> Execute Action
                            </button>
                        </form>
                    </div>
                `;

                // Attaches the event listener to the workflow form after it is rendered
                const attachWorkflowFormListener = () => {
                    const workflowForm = document.getElementById('workflow-form');
                    if (workflowForm) {
                        workflowForm.addEventListener('submit', handleWorkflowSubmit);
                    }
                };
                
                // Handles the submission of the workflow form
                const handleWorkflowSubmit = (e) => {
                    e.preventDefault();
                    const workflowType = document.getElementById('workflow-type').value;
                    const businessReason = document.getElementById('business-reason').value;
                    
                    const selectedWorkflowName = workflowOptions.find(wf => wf.id === workflowType).name;
                    
                    // Simulate API call and provide user feedback
                    const message = `Successfully initiated the workflow to "${selectedWorkflowName.toLowerCase()}".\n\nReason: ${businessReason || 'Not provided'}.`;
                    showMessageBox('Action Initiated', message);
                    
                    // Clear the form after submission
                    e.target.reset();
                };

                // Function to render the new KPIs UI with cards and a chart
                const renderKPIs = () => {
                    const mttr = mockData.kpis.find(k => k.name === 'MTTR');
                    const sla = mockData.kpis.find(k => k.name === 'SLA Breaches');
                    const availability = mockData.kpis.find(k => k.name === 'Availability');
                    
                    return `
                        <h1 class="fs-2 fw-bold text-dark mb-4">Key Performance Indicators</h1>
                        
                        <!-- Current KPI Cards -->
                        <div class="row g-4 mb-4">
                            ${renderCard('Current MTTR', `${mttr.value} ${mttr.unit}`, 'bg-info text-white')}
                            ${renderCard('SLA Breaches YTD', `${sla.value} ${sla.unit}`, 'bg-danger text-white')}
                            ${renderCard('Availability', `${availability.value}%`, 'bg-success text-white')}
                        </div>

                        <!-- Historical Trends Section -->
                        <div class="card p-4 mb-4">
                            <h2 class="fs-4 fw-semibold mb-3">Historical Trends: MTTR</h2>
                            <canvas id="historicalKpiChart"></canvas>
                            <p class="mt-4 text-muted">
                                This chart visualizes historical KPI data, identifying trends to inform operational decisions.
                            </p>
                        </div>
                        
                        <!-- Prediction Placeholder -->
                        <div class="card p-4">
                            <h2 class="fs-4 fw-semibold mb-3">Proactive KPI Prediction</h2>
                            <p>
                                Using machine learning, this module will analyze trends to forecast future KPI performance.
                                For example, it could predict a potential increase in MTTR before it happens, allowing for
                                proactive resource allocation and intervention.
                            </p>
                            <div class="alert alert-warning text-center mt-3" role="alert">
                                <strong>Feature Coming Soon:</strong> AI-powered predictions will enhance this dashboard.
                            </div>
                        </div>
                    `;
                };
                
                // Function to render the new Reports UI with a list of reports
                const renderReports = () => {
                    const reportCards = mockData.reports.map(report => `
                        <div class="card p-4 d-flex flex-row justify-content-between align-items-center mb-3">
                            <div class="flex-grow-1 me-3">
                                <h5 class="fw-bold mb-1">${report.name}</h5>
                                <div class="text-muted small">Type: ${report.type} | Date: ${report.date}</div>
                            </div>
                            <div>
                                <button class="btn btn-sm btn-outline-primary me-2" onclick="showMessageBox('View Report', 'Simulating view for report: ${report.name}')">View</button>
                                <button class="btn btn-sm btn-success" onclick="shareReport(${report.id})">
                                    <i class="bi bi-share-fill me-1"></i>Share
                                </button>
                            </div>
                        </div>
                    `).join('');

                    return `
                        <h1 class="fs-2 fw-bold text-dark mb-4">Reports</h1>
                        <div class="mb-4 d-flex justify-content-between align-items-center">
                            <h2 class="fs-4 fw-semibold mb-0">Automated Reports</h2>
                            <button class="btn btn-outline-primary rounded-pill d-flex align-items-center gap-2" onclick="showMessageBox('Generate Report', 'This would trigger an API call to generate a new report.')">
                                <i class="bi bi-plus-circle"></i> Generate New
                            </button>
                        </div>
                        <div class="card p-4">
                            ${reportCards}
                        </div>
                    `;
                };

                // Main function to render the centralized dashboard with sub-tabs
                const renderCentralizedDashboard = (subTab) => {
                    return `
                        <h1 class="fs-2 fw-bold text-dark mb-4">Centralized Operations</h1>
                        <nav class="mb-4">
                            <div class="nav nav-pills rounded-pill p-1 bg-white shadow-sm" id="nav-tab" role="tablist">
                                <button class="nav-link rounded-pill active" data-centralized-tab="overview">
                                    <i class="bi bi-graph-up me-2"></i>Overview
                                </button>
                                <button class="nav-link rounded-pill" data-centralized-tab="discovery">
                                    <i class="bi bi-search me-2"></i>Discovery
                                </button>
                                <button class="nav-link rounded-pill" data-centralized-tab="netreo">
                                    <i class="bi bi-diagram-3 me-2"></i>Netreo
                                </button>
                                <button class="nav-link rounded-pill" data-centralized-tab="aiops">
                                    <i class="bi bi-robot me-2"></i>AIOps
                                </button>
                            </div>
                        </nav>
                        <div id="centralized-content-area" class="tab-content">
                            ${renderCentralizedSubTab(subTab)}
                        </div>
                    `;
                };
                
                // Function to render content for each centralized sub-tab
                const renderCentralizedSubTab = (subTab) => {
                    switch (subTab) {
                        case 'discovery':
                            return renderDiscoveryDashboard();
                        case 'netreo':
                            return renderNetreoDashboard();
                        case 'aiops':
                            return renderAIOpsDashboard();
                        case 'overview':
                        default:
                            return renderCentralizedOverview();
                    }
                };
                
                // Renders the overview sub-tab content
                const renderCentralizedOverview = () => `
                    <p class="text-muted mb-4">
                        This unified view integrates data from Discovery, Netreo, and AIOps to provide a holistic overview of your IT environment.
                    </p>
                    <div class="row g-4 mb-4">
                        <div class="col-md-4">
                            <div class="card p-4 bg-primary text-white">
                                <div class="d-flex align-items-center mb-3">
                                    <i class="bi bi-geo-alt-fill me-3 fs-3"></i>
                                    <h5 class="card-title fw-bold mb-0">Discovery</h5>
                                </div>
                                <h2 class="display-5 fw-bold">${mockData.centralized.discovery.devicesFound}</h2>
                                <p class="card-text">Total assets discovered</p>
                                <div class="mt-2 small">Last run: ${mockData.centralized.discovery.lastRun}</div>
                                <div class="mt-2 small">Status: ${mockData.centralized.discovery.status}</div>
                                <button class="btn btn-light btn-sm mt-3 fw-semibold" onclick="renderContent('centralized', 'discovery')">View Details</button>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card p-4 bg-success text-white">
                                <div class="d-flex align-items-center mb-3">
                                    <i class="bi bi-hdd-fill me-3 fs-3"></i>
                                    <h5 class="card-title fw-bold mb-0">Netreo</h5>
                                </div>
                                <h2 class="display-5 fw-bold">${mockData.centralized.netreo.monitoredDevices}</h2>
                                <p class="card-text">Devices actively monitored</p>
                                <div class="mt-2 small">Alerts (24h): ${mockData.centralized.netreo.alertsLast24h}</div>
                                <div class="mt-2 small">Connector Status: ${mockData.centralized.netreo.connectorStatus}</div>
                                <button class="btn btn-light btn-sm mt-3 fw-semibold" onclick="renderContent('centralized', 'netreo')">View Alerts</button>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card p-4 bg-info text-white">
                                <div class="d-flex align-items-center mb-3">
                                    <i class="bi bi-robot me-3 fs-3"></i>
                                    <h5 class="card-title fw-bold mb-0">AIOps Insights</h5>
                                </div>
                                <h2 class="display-5 fw-bold">${mockData.centralized.aiops.activeInsights}</h2>
                                <p class="card-text">Active insights and recommendations</p>
                                <div class="mt-2 small">Predicted Outages: ${mockData.centralized.aiops.predictedOutages}</div>
                                <div class="mt-2 small">Top Insight: "${mockData.centralized.aiops.insights[0].title}"</div>
                                <button class="btn btn-light btn-sm mt-3 fw-semibold" onclick="renderContent('centralized', 'aiops')">Review Insights</button>
                            </div>
                        </div>
                    </div>
                `;

                // Renders the Discovery dashboard content
                const renderDiscoveryDashboard = () => `
                    <div class="card p-4 mb-4">
                        <h2 class="fs-4 fw-semibold mb-3">Discovery Scan</h2>
                        <p class="text-muted">Initiate a new discovery scan by providing network credentials and IP ranges.</p>
                        <form id="discovery-form">
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label for="ip-range" class="form-label">IP Address Range (CIDR)</label>
                                    <input type="text" class="form-control rounded-pill" id="ip-range" placeholder="e.g., 192.168.1.0/24">
                                </div>
                                <div class="col-md-6">
                                    <label for="discovery-user" class="form-label">Username</label>
                                    <input type="text" class="form-control rounded-pill" id="discovery-user" placeholder="e.g., admin">
                                </div>
                                <div class="col-12">
                                    <label for="discovery-pass" class="form-label">Password</label>
                                    <input type="password" class="form-control rounded-pill" id="discovery-pass">
                                </div>
                                <div class="col-12 text-center">
                                    <button type="submit" class="btn btn-primary rounded-pill w-100 fw-semibold mt-3">
                                        <i class="bi bi-play-circle me-2"></i> Run Discovery Scan
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>

                    <!-- NEW: Section for Discovered Assets -->
                    <div class="card p-4 mb-4">
                        <h2 class="fs-4 fw-semibold mb-3">Discovered Assets</h2>
                        <p class="text-muted">A comprehensive view of all discovered infrastructure, applications, and services.</p>
                        <div class="row g-3">
                            ${mockData.centralized.discovery.discoveredAssets.map(asset => `
                                <div class="col-md-6 col-lg-4">
                                    <div class="card p-3 rounded-2 border ${asset.status === 'Operational' ? 'border-success' : asset.status === 'Degraded' ? 'border-warning' : 'border-danger'}">
                                        <div class="d-flex align-items-center justify-content-between">
                                            <h5 class="fw-semibold mb-0">${asset.name}</h5>
                                            <span class="badge rounded-pill bg-${asset.status === 'Operational' ? 'success' : asset.status === 'Degraded' ? 'warning' : 'danger'}">${asset.status}</span>
                                        </div>
                                        <div class="small text-muted mt-1">${asset.type} | ${asset.ip}</div>
                                        <div class="small text-muted mt-2">OS: ${asset.os}</div>
                                    </div>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                    
                    <div class="card p-4">
                        <h2 class="fs-4 fw-semibold mb-3">Recent Scan Results</h2>
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>IP Address</th>
                                        <th>Hostname</th>
                                        <th>OS</th>
                                        <th>Type</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ${mockData.centralized.discovery.scanResults.map(device => `
                                        <tr>
                                            <td>${device.ip}</td>
                                            <td>${device.hostname}</td>
                                            <td>${device.os}</td>
                                            <td>${device.type}</td>
                                        </tr>
                                    `).join('')}
                                </tbody>
                            </table>
                        </div>
                    </div>
                `;

                // Renders the Netreo dashboard content
                const renderNetreoDashboard = () => `
                    <div class="card p-4 mb-4">
                        <h2 class="fs-4 fw-semibold mb-3">Network Monitoring Status</h2>
                        <div class="row g-3">
                            ${mockData.centralized.netreo.monitored.map(device => `
                                <div class="col-md-6 col-lg-4">
                                    <div class="card p-3 rounded-2 border ${device.status === 'Up' ? 'border-success' : 'border-danger'}">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <h5 class="fw-semibold mb-0">${device.name}</h5>
                                            <span class="badge ${device.status === 'Up' ? 'bg-success' : 'bg-danger'}">${device.status}</span>
                                        </div>
                                        <div class="small text-muted mt-2">
                                            <span>Latency: ${device.latency}</span> | 
                                            <span>CPU: ${device.cpu}</span> | 
                                            <span>Memory: ${device.memory}</span>
                                        </div>
                                    </div>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                    <div class="card p-4">
                        <h2 class="fs-4 fw-semibold mb-3">Recent Alerts</h2>
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>Device</th>
                                        <th>Alert Type</th>
                                        <th>Severity</th>
                                        <th>Timestamp</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ${mockData.centralized.netreo.alerts.map(alert => `
                                        <tr>
                                            <td>${alert.device}</td>
                                            <td>${alert.type}</td>
                                            <td><span class="badge bg-${alert.severity === 'Critical' ? 'danger' : 'warning'}">${alert.severity}</span></td>
                                            <td>${alert.timestamp}</td>
                                        </tr>
                                    `).join('')}
                                </tbody>
                            </table>
                        </div>
                    </div>
                `;

                // Renders the AIOps dashboard content
                const renderAIOpsDashboard = () => `
                    <div class="card p-4">
                        <h2 class="fs-4 fw-semibold mb-3">AI-Powered Insights</h2>
                        <p class="text-muted">Review the latest intelligent insights and recommendations generated by the AIOps engine.</p>
                        <div class="list-group list-group-flush">
                            ${mockData.centralized.aiops.insights.map(insight => `
                                <div class="list-group-item list-group-item-action border-0 px-0 py-3">
                                    <div class="d-flex justify-content-between align-items-start">
                                        <div>
                                            <h5 class="mb-1 fw-bold">${insight.title}</h5>
                                            <p class="mb-1 text-muted small">${insight.description}</p>
                                        </div>
                                        <span class="badge bg-${insight.severity === 'High' ? 'danger' : 'warning'}">${insight.severity}</span>
                                    </div>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                `;
                
                // Function to render the Chart.js chart for KPIs
                const renderCharts = () => {
                    // Render Dashboard KPI chart (if it exists)
                    const dashboardKpiCanvas = document.getElementById('dashboardKpiChart');
                    if (dashboardKpiCanvas) {
                         new Chart(dashboardKpiCanvas, {
                            type: 'bar',
                            data: {
                                labels: mockData.kpis.map(kpi => kpi.name),
                                datasets: [{
                                    label: 'Current KPI Values',
                                    data: mockData.kpis.map(kpi => kpi.value),
                                    backgroundColor: ['rgba(54, 162, 235, 0.6)', 'rgba(255, 99, 132, 0.6)', 'rgba(75, 192, 192, 0.6)'],
                                    borderColor: ['rgba(54, 162, 235, 1)', 'rgba(255, 99, 132, 1)', 'rgba(75, 192, 192, 1)'],
                                    borderWidth: 1
                                }]
                            },
                            options: {
                                responsive: true,
                                plugins: {
                                    legend: { position: 'top' },
                                    tooltip: { enabled: true }
                                },
                                scales: { y: { beginAtZero: true } }
                            }
                        });
                    }

                    // Render Historical KPI chart (if it exists)
                    const historicalKpiCanvas = document.getElementById('historicalKpiChart');
                    if (historicalKpiCanvas) {
                        new Chart(historicalKpiCanvas, {
                            type: 'line',
                            data: {
                                labels: mockData.historicalKpis.labels,
                                datasets: [{
                                    label: 'MTTR (minutes)',
                                    data: mockData.historicalKpis.mttrData,
                                    borderColor: 'rgb(75, 192, 192)',
                                    tension: 0.1,
                                    fill: false
                                }]
                            },
                            options: {
                                responsive: true,
                                plugins: {
                                    legend: { position: 'top' },
                                    title: { display: false }
                                },
                                scales: {
                                    y: {
                                        beginAtZero: true,
                                        title: {
                                            display: true,
                                            text: 'Minutes'
                                        }
                                    },
                                    x: {
                                        title: {
                                            display: true,
                                            text: 'Month'
                                        }
                                    }
                                }
                            }
                        });
                    }
                };

                // Function to simulate sharing a report via Outlook
                const shareReport = (reportId) => {
                    const report = mockData.reports.find(r => r.id === reportId);
                    if (!report) {
                        showMessageBox('Error', 'Report not found.');
                        return;
                    }

                    const subject = `Postmortem Report: ${report.name}`;
                    const body = `Hello Team,\n\nPlease find the attached PDF for the ${report.name}.\n\nThis report provides a detailed analysis of recent incidents and KPI trends.\n\nBest regards,\nYour SARS BHOM Intergration App`;
                    const outlookLink = `https://outlook.live.com/owa/?path=/mail/action/compose&subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
                    
                    // We can't actually attach a PDF, so we'll simulate it with a message and the link.
                    showMessageBox('Share Report', `Simulating PDF generation and sharing via Outlook.\n\nOpening Outlook Web App...`);
                    // In a real app, you would have a backend service generate the PDF and provide a link.
                    window.open(outlookLink, '_blank');
                };
                
                // --- Message Box Functions (alternative to alert) ---
                const showMessageBox = (title, body) => {
                    const messageBox = document.getElementById('messageBox');
                    document.getElementById('messageBoxLabel').textContent = title;
                    document.getElementById('messageBoxBody').textContent = body;
                    const myModal = new bootstrap.Modal(messageBox);
                    myModal.show();
                };
            });
        })();
    </script>

</body>
</html>
