<?php
    require_once('db.php');
    header("Content-Type: application/json");
    if(isset($_POST['submit'])){
        $sql = "SELECT 
                    i.id,
                    i.title,
                    i.notes,
                    i.priority,
                    i.status,
                    i.created_at,
                    u.name
                FROM incidents i
                INNER JOIN users u ON i.assign_to = u.id;";
        $result = $conn->query($sql);
        if ($result->num_rows >0) {
            $incidents = $result->fetch_all(MYSQLI_ASSOC);
            $response = array(
                'success' => true,
                'message' => 'Successfully fetched incidents',
                'incidents' => $incidents
            );
        } else{
            $response = array(
                'success' => false,
                'message' => 'Failed to fetch incidents'
            );
        }

        echo json_encode($response);
        exit;
    }
?>