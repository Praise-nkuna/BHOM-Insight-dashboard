<?php
    require_once('db.php');
    header("Content-Type: application/json");
    if(isset($_POST['title'])){
        $title= $conn->real_escape_string($_POST['title']);
        $notes= $conn->real_escape_string($_POST['notes']);
        $prioty= $conn->real_escape_string($_POST['prioty']);
        $assigned= $conn->real_escape_string($_POST['assigned']);
        
        $sqlInsert = "INSERT INTO `incidents`(`title`, `notes`, `priority`, `assign_to`) VALUES ('$title','$notes','$prioty','$assigned')";
        $result = $conn->query($sqlInsert);
        if ($result === TRUE) {
            $response = array(
                'success' => true,
                'message' => 'Successfully lodged an incident'
            );
        } else{
            $response = array(
                'success' => false,
                'message' => 'Failed to lodge an incident'
            );
        }

        echo json_encode($response);
        exit;
        # code...
    }
?>